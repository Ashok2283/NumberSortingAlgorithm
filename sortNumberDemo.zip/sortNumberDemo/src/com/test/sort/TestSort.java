package com.test.sort;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TestSort extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int temp;

	
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		res.setContentType("text/html");
		long start = System.currentTimeMillis();
		String sortNumber = req.getParameter("num");
		String[] numbers = sortNumber.split(",");
		int[] intNumbers = new int[numbers.length];

		for (int i = 0; i < numbers.length; i++) {
			intNumbers[i] = Integer.parseInt(numbers[i]);
		}

		int orderedNums[] = new int[intNumbers.length];

		for (int i = 0; i < intNumbers.length; i++) {
			temp = 0;
			for (int j = 0; j < intNumbers.length; j++) {
				if (intNumbers[i] > intNumbers[j]) {
					temp++;
				}
			}
			orderedNums[temp] = intNumbers[i];
		}


		for (temp = 0; temp < orderedNums.length; temp++) {
			System.out.print(orderedNums[temp] + " ");
		}
       long elapsedTimeMillis = System.currentTimeMillis() - start;
	    
	    float elapsedTimeSec = elapsedTimeMillis/1000F;
	    
	    req.setAttribute("elapsedTimeSec", elapsedTimeSec);

		req.setAttribute("orderedNums", orderedNums);

		
		req.getRequestDispatcher("/number.jsp").forward(req, res);

		
	    req.getRequestDispatcher("/number.jsp").forward(req, res);
		
	}

	
	
	
}
